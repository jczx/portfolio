# Credit card fraud detection

Predict fraud with XGBoost and measure the cost in manual reviews. Built with
Python, DuckDB, scikit-learn and FastAPI; runs locally on a CPU.

## Results

On the final chronological test window of **42,724 transactions**, containing
**52 frauds**, the selected model flagged **216 transactions**:

| Outcome | Count |
|---|---:|
| Fraud detected | 41 |
| Fraud missed | 11 |
| Legitimate transactions flagged | 175 |

Recall: **78.85%**. Precision: **18.98%**. Review rate: **0.506%**.
Average precision: **0.7411** (a ranking metric, not accuracy).
These results come from the saved real-data run, not synthetic tests.

## Method

- DuckDB validates and prepares the ULB credit card dataset: 284,807 transactions,
  492 frauds, two days in September 2013. Inputs are Time, Amount and V1–V28.
- Four chronological windows separate training (60%), calibration (15%),
  threshold selection (10%) and final testing (15%). Equal timestamps stay together.
- Three forward-validation folds compare a dummy baseline, logistic regression
  and XGBoost, including weighted variants. The selected model is unweighted
  XGBoost with depth 3 and 150 trees, chosen by validation average precision.
- Sigmoid calibration uses its own window. The review threshold maximises recall
  within a 1% validation review budget. All choices are frozen before final testing.
- FastAPI loads one saved bundle containing preprocessing, model, calibration
  and threshold. Missing or incompatible models fail clearly.

## Limits

Most alerts were legitimate transactions. Calibration worsened probability quality
on the test set; its fitting window contained only 38 frauds. Weighted XGBoost had
higher test average precision, but replacing the model after seeing test results
would invalidate model selection. Two days of anonymised historical data do not
establish future performance. This is a portfolio study, not a deployed banking system.

## Run locally

Use Python 3.12. Download [ULB dataset version 3](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)
and place `creditcard.csv` in `data/`. Review the dataset's access terms; raw data and
model binaries are excluded from the source package.

```powershell
python -m pip install uv==0.8.22
uv sync --frozen
uv run --frozen python main.py train --csv data/creditcard.csv --run-dir artifacts/reproduction --config config/default.json
uv run --frozen python main.py evaluate --run-dir artifacts/reproduction --output reports/reproduction
$env:FRAUD_MODEL_PATH = "artifacts/reproduction/model.joblib"
uv run --frozen uvicorn fraud.api:app --host 127.0.0.1 --port 8000
```

Use new or empty output directories for each run. Open `http://127.0.0.1:8000/docs`
to inspect the API. `GET /health` reports readiness; `POST /predict` returns the
estimated probability, review flag, threshold and model version.

```powershell
curl.exe -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" --data-binary "@examples/transaction.json"
uv run --frozen ruff check .
uv run --frozen pytest -q
```

The request example is synthetic. Only load model files you trust.
A Dockerfile and GitHub Actions workflow are included; Docker needs a running Linux engine.

## Evidence

- [Final results](reports/real/results.md) and [full metrics](reports/real/metrics.json)
- [Model card](docs/model-card.md), [dataset notes](docs/dataset.md) and [results interpretation](docs/results-analysis.md)

To refresh the portfolio summary and downloadable source from the existing frozen
report, without retraining:

```powershell
uv run --frozen python scripts/export_portfolio.py --output ../portfolio/public
```

The exporter verifies that the report matches its frozen manifest and rejects synthetic
results. Its source archive includes code and aggregate evidence, excluding raw data,
model binaries, local environments and internal instruction files.
