"""Convenience command entrypoint: python main.py --help."""

from fraud.cli import main

if __name__ == "__main__":
    main()
