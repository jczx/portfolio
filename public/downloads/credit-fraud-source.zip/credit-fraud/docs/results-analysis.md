# Interpretation of the completed ULB run

The frozen model version is `36decdf5344f-xgboost_unweighted`.
The local CSV SHA-256 is
`76274b691b16a6c49d3f159c883398e03ccd6d1ee12d9d8ee38f4b4b98551a89`.
All numbers below come from the completed run's manifests and metrics, not synthetic fixtures.

## Chronological evidence

| Window | Transactions | Fraud | Elapsed seconds, inclusive |
|---|---:|---:|---|
| Training | 170,882 | 360 | 0–120,395 |
| Calibration | 42,723 | 38 | 120,396–139,320 |
| Threshold selection | 28,478 | 42 | 139,321–151,327 |
| Final test | 42,724 | 52 | 151,328–172,792 |

The default split passed the positive-count checks without adjustment. No exact row or
full-predictor signature overlapped across windows. There were 1,081 exact duplicate rows
after first occurrences within windows (640/113/145/183). Excluding Time, training and
testing shared 271 predictor signatures. Independence and confidence should not be assumed
from chronological separation alone.

## Model choice and feature comparison

The 17-candidate search used 51 forward-fold fits. Unweighted XGBoost with depth 3 and
original features had mean AP 0.8136, compared with 0.7983 for the best weighted XGBoost,
0.7607 for weighted logistic regression and 0.6480 for unweighted logistic regression.
The dummy mean AP was 0.00187. Original Amount outperformed log Amount for logistic regression;
the tree results tied between these variants under the tested configuration, so the
predeclared candidate-order tie rule kept original features.

Final-test AP was 0.7411 for the selected model. Weighted XGBoost reached 0.7540 on the same
test, but changing the selected model in response would contaminate the evaluation.
Weighted logistic and unweighted logistic achieved 0.6879 and 0.6018 respectively.
The test set is a comparison of frozen alternatives, not another tuning window.

## Review policy and consequences

The default policy allowed at most 1% validation reviews. The chosen threshold
`0.0003076360734565164` actually reviewed 155 of 28,478 validation transactions (0.544%),
detecting 38 of 42 frauds. Additional reviews within the budget did not increase recall,
so the precision tie-break selected this smaller workload.

These are *threshold-window* scenarios, optimised and described on the same data:

| Capacity ceiling | Reviews | False alerts | Frauds detected / total | Recall |
|---|---:|---:|---:|---:|
| 0.1% | 28 | 2 | 26 / 42 | 61.90% |
| 0.5% | 58 | 21 | 37 / 42 | 88.10% |
| 1% | 155 | 117 | 38 / 42 | 90.48% |
| 2% | 155 | 117 | 38 / 42 | 90.48% |
| 5% | 155 | 117 | 38 / 42 | 90.48% |

In final testing the frozen policy reviewed 216 transactions, including 41 frauds and
175 legitimate transactions, missing 11 frauds. Recall was 78.85%, precision 18.98%, F1
0.3060 and review rate 0.506%. This is roughly four false alerts per 1,000 transactions.
The approximate recall interval was 65.97–87.76%; precision interval 14.31–24.74%.
These Wilson intervals do not account for temporal or duplicate dependence.

The very small calibrated threshold is not a typo: fraud is rare and the high-recall
review policy intentionally includes low-probability cases. Most alerts are legitimate.
An arbitrary 0.5 threshold would express a different operating policy.

Under the explicitly hypothetical costs of 2 units per review and 100 per missed fraud,
the final-window scenario is `216*2 + 11*100 = 1,532` arbitrary units. This is not financial
savings, measured bank cost, or evidence of intervention effectiveness.

## Calibration did not improve probability quality

| Final-test measure | Raw model | Sigmoid calibrated |
|---|---:|---:|
| Brier score | 0.00045668 | 0.00049084 |
| Log loss | 0.00317815 | 0.00350344 |

Both probability scores worsened after sigmoid calibration; ranking AP and review decisions
were unchanged in this run because the fitted sigmoid preserved ordering and thresholds
were selected under the same capacity policy. Calibration also worsened these metrics on
the threshold window; the predeclared policy was retained and the weakness documented.
This project does not claim that calibrated necessarily means better calibrated.

The calibration window has only 38 frauds. Several test reliability bins contain only one
or two transactions and others are empty; their jagged rates should not be overinterpreted.
The low-probability calibrated bin contains 42,682 transactions and 17 frauds; the >0.9 bin
contains 32 transactions and 31 frauds. Consult the saved bin counts alongside the plot.

Any subsequent redesign of calibration or the operating policy requires a new validation
plan and an unseen evaluation period. The short historical dataset cannot supply convincing
long-term deployment evidence merely by repeating this test.
