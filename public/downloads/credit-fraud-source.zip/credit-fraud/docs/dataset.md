# Dataset source and limitations

Source: [Machine Learning Group - ULB on Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud),
version 3. The public [metadata API](https://www.kaggle.com/api/v1/datasets/view/mlg-ulb/creditcardfraud)
was checked before downloading. It identifies a public dataset owned by MLG-ULB and gives
the license label `Database: Open Database, Contents: Database Contents`. Refer to the
source's current license terms before redistribution; this repository excludes the raw file.
The public versioned download succeeded without credentials. A browser download or a
locally supplied `creditcard.csv` can be used if access requirements change.

The source describes a Worldline/ULB research collection of European card transactions over
two days in September 2013: 284,807 rows, 492 fraud labels, 284,315 legitimate labels.
The training manifest records the actual supplied file's SHA-256, row count and column types.

| Column | Meaning | Handling |
|---|---|---|
| `Time` | Seconds since the first transaction | Nonnegative double; sorting and predictor |
| `V1`–`V28` | Anonymised PCA components | Finite doubles; cannot recover business meanings |
| `Amount` | Transaction amount | Nonnegative double; original or log1p variant |
| `Class` | 1 fraud, 0 legitimate | Validate as exact binary, store TINYINT, exclude from X |
| `row_id` | Locally generated ingestion order | Stable tie-break and audit only; exclude from X |

No cardholder ID, merchant, geography, protected attribute, label-arrival time or verified
financial recovery is available. Do not invent behavioural aggregates or assert fairness.
Elapsed time is neither a calendar date nor local hour of day. PCA was already performed
upstream; its fit population and possible leakage cannot be audited here.

Identical rows are retained under a predeclared policy: without transaction IDs we cannot
tell duplicate extraction from separate real transactions. Timestamp grouping prevents
exact identical rows from straddling chronological windows. The audit additionally hashes
predictors without Time to expose repeated signatures over time. Hashes carry a small
collision risk; overlapping signatures indicate possible dependence, not proven duplicate
payments. Duplicates within windows can still make estimates overconfident. No test-informed
deduplication rule is used.

The short, old observation period limits evidence about future drift and seasonality.
Assuming every training label is available at the next chronological boundary is optimistic
because investigation delays are unobserved. Minimum-positive checks prevent empty-class
failures, but five positives do not make a reliable calibration study.

Requested source attribution: Andrea Dal Pozzolo, Olivier Caelen, Reid A. Johnson and
Gianluca Bontempi, *Calibrating Probability with Undersampling for Unbalanced Classification*,
IEEE CIDM, 2015. See the Kaggle description for the full related bibliography.
