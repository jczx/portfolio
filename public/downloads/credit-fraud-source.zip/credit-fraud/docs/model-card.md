# Model card

## Intended use

Educational portfolio analysis and local scoring of inputs with the ULB dataset's exact
schema. Outputs illustrate a review decision policy. They must not automatically decline
payments or be treated as definitive fraud findings.

## Model and provenance

The selected bundle is `artifacts/real/model.joblib`; model version, algorithm, feature variant,
parameters, weights, dependency versions and source checksum are recorded in
`artifacts/real/manifest.json` and copied to `reports/real/manifest.json`.
Selection uses training-only forward-validation AP across dummy, logistic regression
and XGBoost candidates. Sigmoid calibration and review threshold are fitted on separate
chronological windows. All choices are frozen before final testing.

Input: Time, V1–V28, Amount. Output: estimated fraud probability, review flag, operating
threshold, model version. The Class label and local row identifiers are excluded.
Only logistic regression learns a StandardScaler, on training rows only; SQL features
are deterministic and saved in the pipeline. Weighting uses fitting-window class counts.

## Evaluation

Completed model `36decdf5344f-xgboost_unweighted`: original features, depth 3, 150 trees.
The final 42,724 transactions contain 52 frauds; 41 were reviewed and 11 missed, with
175 legitimate reviews. AP is 0.7411, recall 78.85%, precision 18.98%, review rate 0.506%.
Sigmoid calibration worsened Brier score and log loss. See
[results interpretation](results-analysis.md) for the full limitations and capacity scenarios.

Read [actual final-test results](../reports/real/results.md) and
[machine-readable metrics](../reports/real/metrics.json). AP and trapezoidal PR-AUC are
reported separately, with ROC-AUC, precision/recall/F1, confusion counts, workload and
calibration scores. Reliability plots and bin counts accompany probability metrics.
The selected threshold is tied to the configured validation capacity, not to final-test labels.
Descriptive test comparison must not be used to reselect a model.

## Limitations and risks

Two days of anonymised, historical European transactions cannot establish performance on
future transactions or other populations. Unknown upstream PCA and label delays restrict
the leakage audit. Duplicate signatures may create dependence and optimistic uncertainty.
Fraud cases are sparse. Wilson intervals assume independent Bernoulli trials, which may
not hold. Calibration may drift and review workload may exceed validation capacity.

Anonymised feature importance is a description of fitted model use, not a causal explanation
of fraud. No protected attributes are available, so subgroup fairness has not been measured.
There is no evidence of financial savings, regulatory compliance or production readiness.
Synthetic CI metrics validate software execution only.

## Operational handling

Load only trusted artifacts under the locked dependencies. Missing, corrupt or incompatible
artifacts return unready health status; never substitute an untrained fallback. Rebuild
calibration and threshold whenever the classifier or transformations are refit. The local
API has no authentication or production monitoring. Docker execution requires a running
Linux engine and remains subject to the verification record.
