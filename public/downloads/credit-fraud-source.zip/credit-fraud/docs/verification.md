# Verification record

Implementation and verification completed locally on Windows with Python 3.12.5.
The actual dependency versions are recorded in `reports/real/manifest.json`; `uv.lock`
was generated and a frozen dependency sync completed successfully.

| Check | Actual outcome |
|---|---|
| Ruff on project code and source notebook | Passed |
| pytest | **17 passed**, 9.34 seconds in the final full-suite run |
| Synthetic CLI generation, training, final evaluation | Passed; outputs explicitly labelled software tests |
| Real ULB version-3 download | Succeeded through the public Kaggle API without credentials |
| Real training | Completed 17 candidates across three forward folds, then five finalist fits |
| Real final evaluation | Completed after freeze; saved metrics, manifest and three report figures |
| Standalone DuckDB ingest and explore commands | Passed on all 284,807 real rows; training-window SQL reports and distributions generated |
| Artifact roundtrip, corruption handling, schema and version checks | Covered by bundle/API tests; version mismatch coverage described below |
| Local uvicorn HTTP process | `/health` and example `/predict` passed with the real model; process stopped afterward |
| Exploration notebook | nbformat validation and execution passed against the real run's database |
| Plot inspection | Final-test PR and reliability plots visually inspected |
| Docker runtime | Not executed: Docker Desktop Linux engine was not running |
| Remote GitHub Actions | Authored, not executed from this workspace |

The initial suite had 16 passes and one test-fixture failure: its synthetic label edit
also affected the threshold window. The fixture was corrected to remove labels only in
the final test window, then the whole suite passed. No model policy was changed based on
final-test performance. Third-party deprecation warnings remain (205 in the final suite,
primarily matplotlib/pyparsing and Starlette/AnyIO); they did not prevent execution.
Notebook execution emitted a Windows ZeroMQ event-loop warning and completed successfully.

Meaningful tests cover strict CSV types and input rejection, label/identifier exclusion,
reordered headers, tied chronological boundaries, class-count guards, forward-only folds,
duplicate signature overlap, train-only scaling and imbalance weights, SQL transform
consistency, capacity ties, complete synthetic modelling, frozen calibration references,
serialization, artifact checksum tampering, API response schema and invalid numeric JSON.
Artifact dependency versions are checked in the loader; the test suite directly exercises
feature-schema incompatibility and corrupt/missing files rather than every package mismatch.

Reproduce checks from the repository root:

```powershell
uv run --frozen ruff check .
uv run --frozen pytest -q
uv run --frozen python scripts/verify_local.py artifacts/real/model.joblib
$env:FRAUD_NOTEBOOK_DATABASE = "artifacts/real/data.duckdb"
uv run --frozen python scripts/execute_notebook.py
```

`verify_local.py` chooses an available local port and always stops its own API subprocess.
The notebook execution script writes an ignored executed copy to
`reports/notebook-executed.ipynb`; its clean source stays in `notebooks/`.

## Portfolio update — 12 October 2026

Ruff passed; pytest passed all 21 tests. Four export tests check the frozen
results and reject synthetic data, changed manifests and mismatched model
selection. Model fitting, calibration and thresholds were not changed.
