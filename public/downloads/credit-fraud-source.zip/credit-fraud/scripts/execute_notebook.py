"""Validate and execute exploration without overwriting its clean source notebook."""

from pathlib import Path

import nbformat
from nbclient import NotebookClient


def main():
    notebook = nbformat.read("notebooks/exploration.ipynb", as_version=4)
    nbformat.validate(notebook)
    client = NotebookClient(notebook, timeout=120, kernel_name="python3",
                            resources={"metadata": {"path": str(Path.cwd())}})
    client.execute()
    Path("reports").mkdir(exist_ok=True)
    nbformat.write(notebook, "reports/notebook-executed.ipynb")
    print("Exploration notebook validated and executed successfully")


if __name__ == "__main__":
    main()
