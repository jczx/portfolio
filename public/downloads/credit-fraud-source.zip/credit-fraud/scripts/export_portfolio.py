"""Export a public summary and source archive from the frozen real-data run."""

import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]


def build_summary(report_dir):
    report_dir = Path(report_dir)
    manifest_bytes = (report_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    metrics_bytes = (report_dir / "metrics.json").read_bytes()
    metrics = json.loads(metrics_bytes)
    if metrics["data_kind"] != "locally_supplied_ULB":
        raise ValueError("Only real ULB results may be exported to the portfolio")
    if hashlib.sha256(manifest_bytes).hexdigest() != metrics["frozen_manifest_sha256"]:
        raise ValueError("Report manifest does not match the frozen evaluation")
    for key in ("run_id", "selected_group", "data_kind"):
        if manifest[key] != metrics[key]:
            raise ValueError(f"Report and manifest disagree on {key}")
    if manifest["state"] != "frozen_before_final_test":
        raise ValueError("Model choices must have been frozen before final testing")
    group = metrics["selected_group"]
    selected = metrics["models"][group]["calibrated"]
    fields = ("n", "positives", "average_precision", "precision", "recall", "alerts",
              "alert_rate", "false_positives", "missed_fraud", "confusion_matrix_tn_fp_fn_tp")
    return {
        "run_id": metrics["run_id"],
        "dataset_url": "https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud",
        "selected_group": group,
        "selection_rule": manifest["selection_rule"],
        "validation_capacity": manifest["config"]["review_capacity"],
        "test": {key: selected[key] for key in fields},
        "comparison": [{"group": name, "validation_ap": info["cv"]["mean_ap"],
                        "test_ap": metrics["models"][name]["calibrated"]["average_precision"]}
                       for name, info in manifest["models"].items()],
        "calibration": {kind: {key: metrics["models"][group][kind][key]
                              for key in ("brier_score", "log_loss")}
                        for kind in ("uncalibrated", "calibrated")},
        "evidence": {"manifest_sha256": metrics["frozen_manifest_sha256"],
                     "metrics_sha256": hashlib.sha256(metrics_bytes).hexdigest()},
    }


def export(output_dir):
    summary = build_summary(ROOT / "reports/real")
    # Explicit inclusion keeps local data and internal instructions out of the archive.
    paths = ["README.md", "pyproject.toml", "uv.lock", "main.py", "Dockerfile",
             ".dockerignore", ".gitignore", ".python-version", "data/.gitkeep",
             "docs/dataset.md", "docs/model-card.md", "docs/results-analysis.md",
             "docs/verification.md", "reports/real/metrics.json", "reports/real/manifest.json",
             "reports/real/results.md", "scripts/export_portfolio.py",
             "scripts/verify_local.py", "scripts/execute_notebook.py",
             "notebooks/exploration.ipynb"]
    for pattern in ("fraud/*.py", "fraud/sql/*.sql", "config/*.json", "tests/*.py",
                    "examples/*.json", ".github/workflows/*.yml"):
        paths.extend(str(path.relative_to(ROOT)) for path in sorted(ROOT.glob(pattern)))
    output_dir = Path(output_dir)
    (output_dir / "data").mkdir(parents=True, exist_ok=True)
    (output_dir / "downloads").mkdir(parents=True, exist_ok=True)
    (output_dir / "data/fraud-results.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with ZipFile(output_dir / "downloads/credit-fraud-source.zip", "w", ZIP_DEFLATED) as archive:
        for relative in paths:
            archive.write(ROOT / relative, "credit-fraud/" + relative.replace("\\", "/"))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Portfolio public directory")
    args = parser.parse_args()
    result = export(args.output)
    print(f"Exported frozen run {result['run_id']}")
