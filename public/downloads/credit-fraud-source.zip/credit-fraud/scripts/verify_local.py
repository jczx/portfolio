"""Exercise a real uvicorn process; close the process when the checks finish."""

import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen


def main():
    artifact = Path(sys.argv[1] if len(sys.argv) > 1 else "artifacts/real/model.joblib").resolve()
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    environment = {**os.environ, "FRAUD_MODEL_PATH": str(artifact)}
    process = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "fraud.api:app", "--host", "127.0.0.1", "--port", str(port)],
        env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(100):
            if process.poll() is not None:
                raise RuntimeError(process.stderr.read().decode())
            try:
                with urlopen(base + "/health", timeout=1) as response:
                    health = json.load(response)
                break
            except OSError:
                time.sleep(.2)
        else:
            raise TimeoutError("API did not become ready in 20 seconds")
        payload = Path("examples/transaction.json").read_bytes()
        request = Request(base + "/predict", data=payload, headers={"Content-Type": "application/json"})
        with urlopen(request, timeout=10) as response:
            prediction = json.load(response)
        assert health["ready"]
        assert 0 <= prediction["fraud_probability"] <= 1
        assert prediction["model_version"] == health["model_version"]
        assert prediction["review_flag"] == (prediction["fraud_probability"] >= prediction["threshold"])
        print(json.dumps({"health": health, "example_prediction": prediction}, indent=2))
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()


if __name__ == "__main__":
    main()
