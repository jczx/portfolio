import duckdb
import numpy as np
import pytest

from fraud.data import ingest, load_frame
from fraud.schema import FEATURES, validate_features, xy
from fraud.splits import chronological_windows, duplicate_audit, forward_folds


def test_ingestion_types_and_label_exclusion(dataset):
    _, database, frame = dataset
    X, y = xy(frame)
    assert list(X.columns) == FEATURES
    assert "Class" not in X and "row_id" not in X
    assert set(y) == {0, 1}
    with duckdb.connect(str(database), read_only=True) as con:
        schema = {r[0]: r[1] for r in con.execute("DESCRIBE transactions").fetchall()}
    assert schema["Class"] == "TINYINT"
    assert all(schema[name] == "DOUBLE" for name in FEATURES)
    with pytest.raises(ValueError, match="no label"):
        validate_features(frame)


@pytest.mark.parametrize("column,value", [("V1", np.nan), ("V1", np.inf), ("Class", .2),
                                          ("Class", 2), ("Time", -1), ("Amount", -10)])
def test_bad_data_rejected_before_replacement(dataset, column, value):
    path, database, frame = dataset
    original = frame.copy()
    frame[column] = frame[column].astype(float)
    frame.loc[0, column] = value
    frame.drop(columns="row_id").to_csv(path, index=False)
    with pytest.raises(ValueError, match="invalid rows"):
        ingest(path, database)
    assert load_frame(database).equals(original)


def test_bad_header_and_reordered_header(dataset):
    path, database, frame = dataset
    reversed_columns = list(reversed([*FEATURES, "Class"]))
    frame[reversed_columns].to_csv(path, index=False)
    ingest(path, database)
    assert load_frame(database).equals(frame)
    frame.drop(columns="V1").to_csv(path, index=False)
    with pytest.raises(ValueError, match="exactly"):
        ingest(path, database)


def test_time_groups_disjoint_and_exhaustive(dataset):
    frame = dataset[2]
    windows = chronological_windows(frame)
    assert sum(map(len, windows.values())) == len(frame)
    for left, right in zip(list(windows.values())[:-1], list(windows.values())[1:]):
        assert left.Time.max() < right.Time.min()
        assert set(left.row_id).isdisjoint(right.row_id)
    for fit, validation in forward_folds(windows["train"]):
        assert fit.Time.max() < validation.Time.min()
        assert validation.Time.max() <= windows["train"].Time.max()


def test_no_silent_single_class_windows(dataset):
    frame = dataset[2]
    test_start = chronological_windows(frame)["test"].Time.min()
    frame.loc[frame.Time >= test_start, "Class"] = 0
    with pytest.raises(ValueError, match="test needs"):
        chronological_windows(frame)


def test_duplicate_audit_exposes_non_time_overlap(dataset):
    windows = chronological_windows(dataset[2])
    columns = FEATURES[1:]
    windows["test"].loc[windows["test"].index[0], columns] = windows["train"].iloc[0][columns]
    audit = duplicate_audit(windows)
    assert audit["predictors_without_time"]["cross_window_shared_signatures"]["train__test"] >= 1
    assert audit["exact_rows"]["cross_window_shared_signatures"]["train__test"] == 0
