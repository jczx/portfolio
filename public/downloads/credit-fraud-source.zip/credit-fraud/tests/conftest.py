import pytest

from fraud.data import ingest, load_frame
from fraud.evaluate import evaluate
from fraud.synthetic import make_synthetic
from fraud.train import train


@pytest.fixture
def dataset(tmp_path):
    path = tmp_path / "synthetic.csv"
    make_synthetic(path, rows=1200)
    database = tmp_path / "data.duckdb"
    ingest(path, database)
    return path, database, load_frame(database)


@pytest.fixture(scope="session")
def trained_run(tmp_path_factory):
    root = tmp_path_factory.mktemp("pipeline")
    path = root / "synthetic.csv"
    make_synthetic(path)
    run = root / "run"
    manifest = train(path, run, "config/smoke.json", synthetic=True)
    report = evaluate(run, root / "report")
    return run, manifest, report
