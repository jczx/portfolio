import json
from pathlib import Path

import pytest

from scripts.export_portfolio import build_summary

REPORT = Path(__file__).resolve().parents[1] / "reports/real"


def test_summary_matches_frozen_results():
    result = build_summary(REPORT)
    report = json.loads((REPORT / "metrics.json").read_text())
    selected = report["models"][report["selected_group"]]["calibrated"]
    assert result["test"] == {key: selected[key] for key in result["test"]}
    assert result["selected_group"] == report["selected_group"]
    assert result["test"]["alerts"] == (result["test"]["false_positives"]
                                         + result["test"]["positives"]
                                         - result["test"]["missed_fraud"])


@pytest.mark.parametrize("change", ["synthetic", "manifest", "selection"])
def test_rejects_unsuitable_or_mismatched_evidence(tmp_path, change):
    manifest = (REPORT / "manifest.json").read_bytes()
    metrics = json.loads((REPORT / "metrics.json").read_text())
    if change == "synthetic":
        metrics["data_kind"] = "synthetic_software_test"
    elif change == "manifest":
        manifest += b" "
    else:
        metrics["selected_group"] = "logistic_unweighted"
    (tmp_path / "manifest.json").write_bytes(manifest)
    (tmp_path / "metrics.json").write_text(json.dumps(metrics))
    with pytest.raises(ValueError):
        build_summary(tmp_path)
