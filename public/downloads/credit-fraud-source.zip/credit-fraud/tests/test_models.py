import joblib
import numpy as np
import pytest

from fraud.artifacts import load_bundle
from fraud.data import load_frame
from fraud.features import SQLFeatures
from fraud.io import checksum
from fraud.metrics import NO_ALERT_THRESHOLD, evaluate_scores, select_threshold
from fraud.models import build_model
from fraud.schema import FEATURES, xy
from fraud.splits import chronological_windows


def test_fold_local_scaling_weights_and_sql_consistency(dataset):
    windows = chronological_windows(dataset[2])
    X, y = xy(windows["train"])
    spec = {"family": "logistic", "weighted": True, "variant": "log_amount", "parameter": 1}
    model = build_model(spec, y, {"seed": 42}).fit(X, y)
    transformed = SQLFeatures("log_amount").fit_transform(X)
    np.testing.assert_allclose(transformed.LogAmount, np.log1p(X.Amount))
    np.testing.assert_allclose(model.named_steps["scale"].mean_, transformed.mean())
    one = X.iloc[[0]][list(reversed(FEATURES))]
    np.testing.assert_allclose(model.predict_proba(one), model.predict_proba(X.iloc[[0]]))
    weighted_xgb = build_model({**spec, "family": "xgboost", "parameter": 3}, y,
                               {"seed": 42, "xgb_estimators": 12, "n_jobs": 1})
    assert weighted_xgb.named_steps["classifier"].scale_pos_weight == (len(y)-y.sum())/y.sum()


def test_capacity_ties_and_zero_alerts():
    y = [1, 0, 1, 0]
    probabilities = [.9, .9, .4, .1]
    assert select_threshold(y, probabilities, .25) == NO_ALERT_THRESHOLD
    assert select_threshold(y, probabilities, .5) == .9
    assert select_threshold(y, [1., 1., 1., 1.], 0) > 1
    m = evaluate_scores(y, probabilities, .9)
    assert m["confusion_matrix_tn_fp_fn_tp"] == [1, 1, 1, 1]
    assert m["false_alerts_per_1000"] == 250
    with pytest.raises(ValueError):
        select_threshold(y, probabilities, 1.1)


def test_full_pipeline_roundtrip_and_frozen_evaluation(trained_run, tmp_path):
    run, manifest, report = trained_run
    assert len(manifest["models"]) == 5
    assert manifest["data_kind"] == "synthetic_software_test"
    assert report["selected_group"] == manifest["selected_group"]
    assert report["frozen_manifest_sha256"] == checksum(run / "manifest.json")
    bundle = load_bundle(run / "model.joblib")
    X, _ = xy(load_frame(run / "data.duckdb").iloc[:20])
    before = bundle.predict(X)
    joblib.dump(bundle, tmp_path / "roundtrip.joblib")
    after = load_bundle(tmp_path / "roundtrip.joblib").predict(X)
    np.testing.assert_array_equal(before, after)
    np.testing.assert_allclose(before, [bundle.predict(X.iloc[[i]])[0] for i in range(len(X))])
    # Sigmoid calibration must wrap the same fitted model, without a second fit.
    assert bundle.calibrator.estimator.estimator is bundle.classifier
    for entry in manifest["models"].values():
        assert entry["validation_calibrated"]["alert_rate"] <= manifest["config"]["review_capacity"]
    bundle.metadata["features"] = ["Class"]
    joblib.dump(bundle, tmp_path / "bad.joblib")
    with pytest.raises(ValueError, match="schema"):
        load_bundle(tmp_path / "bad.joblib")


def test_tampered_artifact_rejected(trained_run, tmp_path):
    import shutil
    from fraud.evaluate import evaluate
    run, manifest, _ = trained_run
    copy = tmp_path / "copied"
    shutil.copytree(run, copy)
    artifact = copy / next(iter(manifest["models"].values()))["artifact"]
    with artifact.open("ab") as stream:
        stream.write(b"tampered")
    with pytest.raises(ValueError, match="changed"):
        evaluate(copy, tmp_path / "report")
