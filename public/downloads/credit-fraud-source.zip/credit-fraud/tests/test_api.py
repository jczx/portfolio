import pytest
from fastapi.testclient import TestClient

from fraud.api import create_app
from fraud.artifacts import load_bundle
from fraud.data import load_frame
from fraud.schema import FEATURES


def test_prediction_contract_and_validation(trained_run):
    run, _, _ = trained_run
    row = load_frame(run / "data.duckdb")[FEATURES].iloc[0].to_dict()
    bundle = load_bundle(run / "model.joblib")
    with TestClient(create_app(run / "model.joblib")) as client:
        assert client.get("/health").json()["ready"] is True
        result = client.post("/predict", json=row)
        assert result.status_code == 200
        body = result.json()
        assert set(body) == {"fraud_probability", "review_flag", "threshold", "model_version"}
        assert body["threshold"] == bundle.threshold
        assert body["review_flag"] == (body["fraud_probability"] >= body["threshold"])
        import pandas as pd
        assert body["fraud_probability"] == pytest.approx(bundle.predict(pd.DataFrame([row]))[0])
        for bad in [{**row, "Class": 0}, {**row, "Amount": -1}, {**row, "V1": "nan"},
                    {**row, "V1": "3.0"}, {**row, "V1": True}, {**row, "Time": None},
                    {key: value for key, value in row.items() if key != "V1"}]:
            assert client.post("/predict", json=bad).status_code == 422
        # Raw JSON numeric overflow is parsed as infinity, and must still be rejected.
        import json
        payload = json.dumps({**row, "V1": "OVERFLOW"}).replace('"OVERFLOW"', "1e999")
        assert client.post("/predict", content=payload,
                           headers={"content-type": "application/json"}).status_code == 422


def test_missing_or_corrupt_artifact_not_ready(tmp_path):
    for path in [tmp_path / "missing.joblib", tmp_path / "bad.joblib"]:
        if path.name == "bad.joblib":
            path.write_bytes(b"not a model")
        with TestClient(create_app(path)) as client:
            assert client.get("/health").status_code == 503
            assert not client.get("/health").json()["ready"]
            assert client.post("/predict", json={name: 0. for name in FEATURES}).status_code == 503
