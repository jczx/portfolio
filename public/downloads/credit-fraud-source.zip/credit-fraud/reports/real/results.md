# ULB: final-test report

Frozen choice: **xgboost_unweighted**.

| Model | Average precision | Trapezoidal PR-AUC | Precision | Recall | Alerts | FP | Missed fraud |
|---|---:|---:|---:|---:|---:|---:|---:|
| dummy_unweighted | 0.0012 | 0.5006 | 0.0000 | 0.0000 | 0 | 0 | 52 |
| logistic_unweighted | 0.6018 | 0.5960 | 0.2000 | 0.8077 | 210 | 168 | 10 |
| xgboost_unweighted | 0.7411 | 0.7406 | 0.1898 | 0.7885 | 216 | 175 | 11 |
| logistic_weighted | 0.6879 | 0.6781 | 0.1200 | 0.8077 | 350 | 308 | 10 |
| xgboost_weighted | 0.7540 | 0.7537 | 0.2181 | 0.7885 | 188 | 147 | 11 |

Thresholds were selected on the preceding validation window. Capacity is a validation constraint, not a guarantee on future alert volume.

See metrics.json for calibration scores, uncertainty intervals and illustrative costs. The dummy score ties all transactions; trapezoidal PR interpolation can appear optimistic. Average precision is the selection metric.
