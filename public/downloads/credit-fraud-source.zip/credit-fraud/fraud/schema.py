"""The dataset has 30 predictors; Class and row_id are never predictors."""

import numpy as np
import pandas as pd

FEATURES = ["Time", *[f"V{i}" for i in range(1, 29)], "Amount"]
RAW_COLUMNS = [*FEATURES, "Class"]


def validate_features(frame: pd.DataFrame) -> pd.DataFrame:
    if len(frame.columns) != len(FEATURES) or set(frame.columns) != set(FEATURES):
        raise ValueError("Expected exactly Time, V1 through V28, Amount; no label or identifiers")
    ordered = frame.loc[:, FEATURES].astype("float64")
    if not np.isfinite(ordered.to_numpy()).all():
        raise ValueError("Features must be finite and non-missing")
    if (ordered[["Time", "Amount"]] < 0).any().any():
        raise ValueError("Time and Amount must be non-negative")
    return ordered


def xy(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    return validate_features(frame[FEATURES]), frame["Class"].astype(int)
