"""Single-transaction local inference API with truthful readiness."""

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, create_model

from fraud.artifacts import load_bundle
from fraud.schema import FEATURES


class StrictTransaction(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False, strict=True)


Transaction = create_model(
    "Transaction", __base__=StrictTransaction,
    **{name: (float, Field(..., ge=0) if name in {"Time", "Amount"} else ...)
       for name in FEATURES})


class Prediction(BaseModel):
    fraud_probability: float
    review_flag: bool
    threshold: float
    model_version: str


def create_app(artifact_path=None):
    path = Path(artifact_path or os.environ.get("FRAUD_MODEL_PATH", "artifacts/real/model.joblib"))

    @asynccontextmanager
    async def lifespan(app):
        app.state.bundle = None
        app.state.error = None
        try:
            bundle = load_bundle(path)
            # Readiness includes an actual inference check, using an explicit probe.
            bundle.predict(pd.DataFrame([{name: 0.0 for name in FEATURES}]))
            app.state.bundle = bundle
        except Exception as exc:
            app.state.error = f"{type(exc).__name__}: {exc}"
            logging.getLogger(__name__).error("Model unavailable: %s", app.state.error)
        yield

    app = FastAPI(title="Fraud detection portfolio API", version="0.1.0", lifespan=lifespan)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, exc):
        # Echoing a rejected infinity/NaN in JSON would itself cause a server error.
        errors = [{key: error[key] for key in ("loc", "msg", "type")}
                  for error in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": errors})

    @app.get("/health")
    def health():
        bundle = app.state.bundle
        if bundle is None:
            return JSONResponse(status_code=503, content={"status": "not_ready", "ready": False,
                                                         "detail": app.state.error})
        return {"status": "ready", "ready": True, "model_version": bundle.model_version,
                "data_kind": bundle.metadata["data_kind"]}

    @app.post("/predict", response_model=Prediction)
    def predict(transaction: Transaction):
        bundle = app.state.bundle
        if bundle is None:
            raise HTTPException(status_code=503, detail="Model unavailable; inspect /health")
        probability = float(bundle.predict(pd.DataFrame([transaction.model_dump()]))[0])
        return Prediction(fraud_probability=probability, review_flag=probability >= bundle.threshold,
                          threshold=bundle.threshold, model_version=bundle.model_version)

    return app


app = create_app()
