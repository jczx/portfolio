"""Static, reproducible plots for reports and the exploration notebook."""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import precision_recall_curve

from fraud.metrics import reliability_table
from fraud.schema import FEATURES


def evaluation_plots(y, predictions, selected, tradeoffs, destination, label):
    fig, ax = plt.subplots(figsize=(8, 5))
    for name, pair in predictions.items():
        precision, recall, _ = precision_recall_curve(y, pair["calibrated"])
        ax.plot(recall, precision, label=name)
    ax.axhline(np.mean(y), linestyle=":", color="gray", label="Prevalence")
    ax.set(xlabel="Recall", ylabel="Precision", title=f"{label}: final-test PR curves")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(destination / "precision_recall.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for mode, probabilities in predictions[selected].items():
        table = reliability_table(y, probabilities)
        table.to_csv(destination / f"reliability_{mode}.csv", index=False)
        occupied = table[table["count"] > 0]
        axes[0].plot(occupied.mean_probability, occupied.observed_rate, "o-", label=mode)
        axes[1].hist(probabilities, bins=np.linspace(0, 1, 21), alpha=0.5, label=mode)
    axes[0].plot([0, 1], [0, 1], "k:")
    axes[0].set(xlabel="Mean probability", ylabel="Observed fraud fraction",
                title="Reliability (fixed bins; sparse positives)")
    axes[1].set(xlabel="Probability", ylabel="Transactions (log scale)", yscale="log")
    for ax in axes:
        ax.legend()
    fig.suptitle(f"{label}: {selected}")
    fig.tight_layout()
    fig.savefig(destination / "calibration.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(tradeoffs.alert_rate, tradeoffs.recall, label="Recall")
    axes[0].plot(tradeoffs.alert_rate, tradeoffs.precision, label="Precision")
    axes[0].set(xlabel="Alert rate", ylabel="Fraction", xlim=(0, 0.1))
    axes[0].legend()
    axes[1].plot(tradeoffs.threshold, tradeoffs.alert_rate, label="Alert rate")
    axes[1].plot(tradeoffs.threshold, tradeoffs.recall, label="Recall")
    axes[1].set(xlabel="Probability threshold", ylabel="Fraction", xlim=(0, 1))
    axes[1].legend()
    fig.suptitle(f"{label}: threshold-selection window (not final test)")
    fig.tight_layout()
    fig.savefig(destination / "threshold_tradeoffs.png", dpi=150)
    plt.close(fig)


def exploration_plot(frame, destination, label):
    fig, axes = plt.subplots(6, 5, figsize=(15, 15))
    for feature, ax in zip(FEATURES, axes.flat):
        for klass in [0, 1]:
            values = frame.loc[frame.Class == klass, feature]
            if feature == "Amount":
                values = np.log1p(values)
            ax.hist(values, bins=30, density=True, histtype="step", label=str(klass))
        ax.set_title("log1p(Amount)" if feature == "Amount" else feature, fontsize=9)
    axes.flat[0].legend(title="Class")
    fig.suptitle(f"{label}: training-window distributions; Time is elapsed seconds")
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(destination / "feature_distributions.png", dpi=130)
    plt.close(fig)
