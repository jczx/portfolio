"""Persist the exact SQL feature transformation alongside learned scaling."""

import duckdb
from sklearn.base import BaseEstimator, TransformerMixin

from fraud.data import sql
from fraud.schema import FEATURES, validate_features


class SQLFeatures(TransformerMixin, BaseEstimator):
    def __init__(self, variant="original"):
        self.variant = variant

    def fit(self, X, y=None):
        validate_features(X)
        if self.variant not in {"original", "log_amount"}:
            raise ValueError("Unknown feature variant")
        self.query_ = sql(f"features_{self.variant}")
        self.feature_names_in_ = FEATURES.copy()
        self.n_features_in_ = len(FEATURES)
        return self

    def transform(self, X):
        frame = validate_features(X)
        with duckdb.connect(config={"threads": 1}) as con:
            con.register("feature_input", frame)
            return con.execute(self.query_).df()

    def get_feature_names_out(self, input_features=None):
        return [*FEATURES[:-1], "LogAmount" if self.variant == "log_amount" else "Amount"]
