"""Commands intentionally separate freezing a run from evaluating its final test."""

import argparse

from fraud.data import explore, ingest, load_frame
from fraud.evaluate import evaluate
from fraud.io import read_json, write_json
from fraud.plots import exploration_plot
from fraud.splits import chronological_windows
from fraud.synthetic import make_synthetic
from fraud.train import train


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    synthetic = commands.add_parser("synthetic", help="Create labelled software-test data")
    synthetic.add_argument("--output", default="data/synthetic.csv")
    synthetic.add_argument("--rows", type=int, default=1200)
    ingestion = commands.add_parser("ingest")
    ingestion.add_argument("--csv", required=True)
    ingestion.add_argument("--database", default="data/fraud.duckdb")
    exploration = commands.add_parser("explore", help="Explore training window only")
    exploration.add_argument("--database", required=True)
    exploration.add_argument("--output", default="reports/exploration")
    exploration.add_argument("--config", default="config/default.json")
    training = commands.add_parser("train")
    training.add_argument("--csv", required=True)
    training.add_argument("--run-dir", required=True)
    training.add_argument("--config", default="config/default.json")
    training.add_argument("--synthetic", action="store_true")
    evaluation = commands.add_parser("evaluate")
    evaluation.add_argument("--run-dir", required=True)
    evaluation.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "synthetic":
        make_synthetic(args.output, args.rows)
        print("Created SYNTHETIC SOFTWARE TEST ONLY data")
    elif args.command == "ingest":
        result = ingest(args.csv, args.database)
        write_json(args.database + ".metadata.json", result)
        print(result)
    elif args.command == "explore":
        from pathlib import Path
        config = read_json(args.config)
        frame = chronological_windows(load_frame(args.database), config["split_fractions"],
                                      config["min_positives"])["train"]
        explore(frame, args.output)
        exploration_plot(frame, Path(args.output), "Training window")
    elif args.command == "train":
        train(args.csv, args.run_dir, args.config, args.synthetic)
    else:
        result = evaluate(args.run_dir, args.output)
        print(f"Final-test report saved to {args.output}; frozen choice: {result['selected_group']}")


if __name__ == "__main__":
    main()
