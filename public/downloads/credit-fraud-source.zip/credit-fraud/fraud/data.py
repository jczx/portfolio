"""Strict CSV ingestion and reusable SQL exploration through DuckDB."""

import csv
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from fraud.io import checksum, write_json
from fraud.schema import FEATURES, RAW_COLUMNS

SQL_DIR = Path(__file__).parent / "sql"


def sql(name: str) -> str:
    return (SQL_DIR / f"{name}.sql").read_text(encoding="utf-8")


def ingest(csv_path: str | Path, database: str | Path) -> dict:
    """Reject malformed schemas, nulls, infinities, bad labels and negative amounts/time."""
    csv_path, database = Path(csv_path), Path(database)
    with csv_path.open(encoding="utf-8-sig", newline="") as stream:
        header = next(csv.reader(stream))
    if len(header) != len(RAW_COLUMNS) or set(header) != set(RAW_COLUMNS):
        raise ValueError(f"CSV must contain exactly {RAW_COLUMNS}")
    database.parent.mkdir(parents=True, exist_ok=True)
    with duckdb.connect(str(database)) as con:
        con.execute("SET threads = 2")
        relation = con.read_csv(str(csv_path), header=True,
                                columns={name: "DOUBLE" for name in header},
                                strict_mode=True)
        relation.create_view("incoming")
        invalid = " OR ".join(f'"{name}" IS NULL OR NOT isfinite("{name}")'
                              for name in RAW_COLUMNS)
        bad = con.execute(f"SELECT count(*) FROM incoming WHERE {invalid} "
                          "OR Class NOT IN (0, 1) OR Time < 0 OR Amount < 0").fetchone()[0]
        if bad:
            raise ValueError(f"CSV contains {bad} invalid rows; no rows silently dropped")
        if con.execute("SELECT count(*) FROM incoming").fetchone()[0] == 0:
            raise ValueError("CSV is empty")
        con.execute("BEGIN TRANSACTION")
        con.execute(sql("ingest"))
        meta = {"csv_sha256": checksum(csv_path), "source_file": csv_path.name,
                "rows": con.execute("SELECT count(*) FROM transactions").fetchone()[0],
                "column_types": {row[0]: row[1] for row in
                                 con.execute("DESCRIBE transactions").fetchall()}}
        con.execute("CREATE OR REPLACE TABLE provenance (csv_sha256 VARCHAR)")
        con.execute("INSERT INTO provenance VALUES (?)", [meta["csv_sha256"]])
        con.execute("COMMIT")
    return meta


def load_frame(database: str | Path, expected_checksum: str | None = None) -> pd.DataFrame:
    with duckdb.connect(str(database), read_only=True) as con:
        if expected_checksum:
            actual = con.execute("SELECT csv_sha256 FROM provenance").fetchone()[0]
            if actual != expected_checksum:
                raise ValueError("Database provenance does not match the frozen run")
        return con.execute(sql("export")).df()


def explore(frame: pd.DataFrame, destination: str | Path) -> dict:
    """Explore a caller-selected window; the CLI uses training data only."""
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    tables = {}
    with duckdb.connect(config={"threads": 2}) as con:
        con.register("analysis_input", frame)
        for name in ["prevalence", "amount_bands", "time_windows", "duplicates"]:
            result = con.execute(sql(name)).df()
            result.to_csv(destination / f"{name}.csv", index=False)
            tables[name] = result.to_dict("records")
        summary = con.execute("SUMMARIZE SELECT " + ", ".join(RAW_COLUMNS)
                              + " FROM analysis_input").df()
        summary.to_csv(destination / "distributions.csv", index=False)
    tables["quality"] = {"rows": len(frame),
                         "missing": frame[RAW_COLUMNS].isna().sum().to_dict(),
                         "non_finite": int((~np.isfinite(frame[RAW_COLUMNS])).sum().sum()),
                         "duplicate_rows_after_first": int(frame.duplicated(RAW_COLUMNS).sum()),
                         "duplicate_predictors_after_first": int(frame.duplicated(FEATURES).sum())}
    write_json(destination / "summary.json", tables)
    return tables
