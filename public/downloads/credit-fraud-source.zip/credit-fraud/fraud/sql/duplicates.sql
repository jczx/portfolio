-- row_id is only a local identifier; it must not mask identical transactions.
SELECT coalesce(sum(copies - 1), 0) AS duplicate_rows_after_first
FROM (
    SELECT * EXCLUDE (row_id), count(*) AS copies
    FROM analysis_input GROUP BY ALL HAVING count(*) > 1
);
