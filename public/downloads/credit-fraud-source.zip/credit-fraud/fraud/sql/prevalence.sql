SELECT Class, count(*) AS transactions,
       count(*)::DOUBLE / sum(count(*)) OVER () AS prevalence,
       avg(Amount) AS mean_amount, median(Amount) AS median_amount,
       min(Time) AS first_elapsed_second, max(Time) AS last_elapsed_second
FROM analysis_input GROUP BY Class ORDER BY Class;
