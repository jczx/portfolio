WITH bands AS (
    SELECT *, CASE WHEN Amount < 10 THEN '1: <10'
                   WHEN Amount < 100 THEN '2: 10-<100'
                   WHEN Amount < 1000 THEN '3: 100-<1000'
                   ELSE '4: >=1000' END AS amount_band
    FROM analysis_input
)
SELECT amount_band, Class, count(*) AS transactions, avg(Amount) AS mean_amount,
       sum(Amount) AS total_amount
FROM bands GROUP BY amount_band, Class ORDER BY amount_band, Class;
