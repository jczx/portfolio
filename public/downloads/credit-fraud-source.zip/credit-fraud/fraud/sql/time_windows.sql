-- Six-hour windows since the first recorded transaction, NOT calendar time.
SELECT floor(Time / 21600)::INTEGER AS elapsed_six_hour_window, Class,
       count(*) AS transactions, avg(Amount) AS mean_amount
FROM analysis_input GROUP BY elapsed_six_hour_window, Class
ORDER BY elapsed_six_hour_window, Class;
