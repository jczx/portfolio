-- read_csv is registered as incoming with explicit DOUBLE column types.
-- Validate Class before casting, so fractional labels cannot silently round.
CREATE OR REPLACE TABLE transactions AS
SELECT row_number() OVER () AS row_id, * EXCLUDE (Class), CAST(Class AS TINYINT) AS Class
FROM incoming;
