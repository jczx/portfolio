"""Probability metrics and capacity-constrained review decisions."""

import numpy as np
import pandas as pd
from sklearn.metrics import (auc, average_precision_score, brier_score_loss, confusion_matrix,
                             f1_score, log_loss, precision_recall_curve, precision_score,
                             recall_score, roc_auc_score)

NO_ALERT_THRESHOLD = float(np.nextafter(1.0, np.inf))


def threshold_table(y, probabilities):
    """Evaluate tied scores together in O(n log n); >= defines every review decision."""
    y, probabilities = np.asarray(y), np.asarray(probabilities, dtype=float)
    if len(y) == 0 or len(y) != len(probabilities):
        raise ValueError("Nonempty, equally sized labels and probabilities required")
    if not np.isfinite(probabilities).all() or ((probabilities < 0) | (probabilities > 1)).any():
        raise ValueError("Probabilities must be finite and in [0, 1]")
    order = np.argsort(-probabilities, kind="stable")
    sorted_p, sorted_y = probabilities[order], y[order]
    ends = np.r_[np.flatnonzero(sorted_p[:-1] != sorted_p[1:]), len(y) - 1]
    alerts = ends + 1
    true_positives = np.cumsum(sorted_y)[ends]
    positive_total = int(y.sum())
    return pd.DataFrame({
        "threshold": np.r_[NO_ALERT_THRESHOLD, sorted_p[ends]],
        "alerts": np.r_[0, alerts], "true_positives": np.r_[0, true_positives],
        "false_positives": np.r_[0, alerts - true_positives],
        "missed_fraud": np.r_[positive_total, positive_total - true_positives],
        "alert_rate": np.r_[0., alerts / len(y)],
        "precision": np.r_[0., true_positives / alerts],
        "recall": np.r_[0., true_positives / max(positive_total, 1)]})


def select_threshold(y, probabilities, capacity):
    if not 0 <= capacity <= 1:
        raise ValueError("Review capacity must be between 0 and 1")
    table = threshold_table(y, probabilities)
    feasible = table[table.alert_rate <= capacity]
    best = feasible.sort_values(["recall", "precision", "threshold"],
                                ascending=False).iloc[0]
    return float(best.threshold)


def wilson(successes, total):
    if total == 0:
        return None
    z, p = 1.96, successes / total
    center = (p + z*z/(2*total)) / (1 + z*z/total)
    half = z * np.sqrt(p*(1-p)/total + z*z/(4*total*total)) / (1 + z*z/total)
    return [float(center-half), float(center+half)]


def evaluate_scores(y, probabilities, threshold, cost_scenario=None):
    y, probabilities = np.asarray(y), np.asarray(probabilities)
    flags = probabilities >= threshold
    tn, fp, fn, tp = confusion_matrix(y, flags, labels=[0, 1]).ravel()
    precision, recall, _ = precision_recall_curve(y, probabilities)
    result = {
        "n": len(y), "positives": int(y.sum()), "threshold": float(threshold),
        "average_precision": float(average_precision_score(y, probabilities)),
        "trapezoidal_pr_auc": float(auc(recall, precision)),
        "roc_auc": float(roc_auc_score(y, probabilities)) if len(np.unique(y)) == 2 else None,
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags, zero_division=0)),
        "f1": float(f1_score(y, flags, zero_division=0)),
        "confusion_matrix_tn_fp_fn_tp": [int(tn), int(fp), int(fn), int(tp)],
        "false_positives": int(fp), "missed_fraud": int(fn),
        "alerts": int(flags.sum()), "alert_rate": float(flags.mean()),
        "false_alerts_per_1000": float(fp / len(y) * 1000),
        "brier_score": float(brier_score_loss(y, probabilities)),
        "log_loss": float(log_loss(y, probabilities, labels=[0, 1])),
        "recall_wilson_95": wilson(tp, tp+fn), "precision_wilson_95": wilson(tp, tp+fp)}
    if cost_scenario is not None:
        if min(cost_scenario.values()) < 0:
            raise ValueError("Illustrative costs cannot be negative")
        result["illustrative_cost_scenario"] = {
            "assumptions": cost_scenario,
            "total_cost": float(flags.sum()*cost_scenario["review_cost"]
                                + fn*cost_scenario["missed_fraud_cost"]),
            "meaning": "Arbitrary currency units; review cost for every alert and fixed cost "
                       "per missed fraud. Not measured savings."}
    return result


def reliability_table(y, probabilities, bins=10):
    # Fixed probability bins expose empty bins and sparse positives explicitly.
    frame = pd.DataFrame({"y": np.asarray(y), "p": probabilities})
    frame["bin"] = pd.cut(frame.p, np.linspace(0, 1, bins+1), include_lowest=True)
    result = frame.groupby("bin", observed=False).agg(
        count=("y", "size"), positives=("y", "sum"),
        mean_probability=("p", "mean"), observed_rate=("y", "mean")).reset_index()
    result["bin"] = result["bin"].astype(str)
    return result
