"""Fit, calibrate and freeze choices without scoring the final test window."""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.frozen import FrozenEstimator
from sklearn.metrics import average_precision_score

from fraud.artifacts import ModelBundle, save_bundle
from fraud.data import SQL_DIR, explore, ingest, load_frame
from fraud.io import checksum, read_json, versions, write_json
from fraud.metrics import evaluate_scores, select_threshold, threshold_table
from fraud.models import build_model, candidates, group_name
from fraud.plots import exploration_plot
from fraud.schema import FEATURES, xy
from fraud.splits import chronological_windows, describe_windows, duplicate_audit, forward_folds


def train(csv_path, run_dir, config_path="config/default.json", synthetic=False):
    config = read_json(config_path)
    sidecar = Path(csv_path).with_suffix(".provenance.json")
    if sidecar.exists() and read_json(sidecar).get("synthetic"):
        synthetic = True
    # Validate the operating policy before fitting any models.
    if any(not 0 <= c <= 1 for c in [config["review_capacity"], *config["capacity_scenarios"]]):
        raise ValueError("Review capacities must be in [0, 1]")
    run_dir = Path(run_dir)
    if run_dir.exists() and any(run_dir.iterdir()):
        raise FileExistsError("Use a new run directory; frozen experiments cannot be overwritten")
    run_dir.mkdir(parents=True, exist_ok=True)
    provenance = ingest(csv_path, run_dir / "data.duckdb")
    frame = load_frame(run_dir / "data.duckdb")
    windows = chronological_windows(frame, config["split_fractions"], config["min_positives"])
    folds = list(forward_folds(windows["train"], config["cv_splits"], config["cv_min_positives"]))
    audit = {"windows": describe_windows(windows), "duplicates": duplicate_audit(windows),
             "forward_folds": [describe_windows({"fit": fit, "validation": validation})
                               for fit, validation in folds]}
    write_json(run_dir / "split_audit.json", audit)
    label = "SYNTHETIC SOFTWARE TEST ONLY" if synthetic else "ULB local dataset"
    explore(windows["train"], run_dir / "exploration")
    exploration_plot(windows["train"], run_dir / "exploration", label)
    search = []
    for spec in candidates(config):
        scores = []
        for fit, validation in folds:
            X, y = xy(fit)
            Xv, yv = xy(validation)
            model = build_model(spec, y, config).fit(X, y)
            scores.append(float(average_precision_score(yv, model.predict_proba(Xv)[:, 1])))
        result = {"spec": spec, "fold_ap": scores, "mean_ap": float(np.mean(scores)),
                  "std_ap": float(np.std(scores))}
        search.append(result)
        print(f"CV {spec}: AP={result['mean_ap']:.5f}", flush=True)
    write_json(run_dir / "cv_results.json", search)
    # Stable candidate order resolves exact ties in favour of simpler/original candidates.
    champions = {}
    for result in search:
        group = group_name(result["spec"])
        if group not in champions or result["mean_ap"] > champions[group]["mean_ap"]:
            champions[group] = result
    winner = max(champions, key=lambda group: champions[group]["mean_ap"])
    identity = json.dumps({"data": provenance["csv_sha256"], "config": config,
                           "versions": versions()}, sort_keys=True)
    code_hashes = {str(p.relative_to(Path(__file__).parent)): checksum(p)
                   for p in sorted(Path(__file__).parent.rglob("*"))
                   if p.suffix in {".py", ".sql"}}
    identity += json.dumps(code_hashes, sort_keys=True)
    run_id = hashlib.sha256(identity.encode()).hexdigest()[:12]
    manifest = {
        "run_id": run_id, "created_utc": datetime.now(timezone.utc).isoformat(),
        "data_kind": "synthetic_software_test" if synthetic else "locally_supplied_ULB",
        "provenance": provenance, "config": config, "versions": versions(),
        "database_sha256": checksum(run_dir / "data.duckdb"),
        "features": FEATURES, "split_audit": audit, "selected_group": winner,
        "selection_rule": "Highest mean forward-validation average precision within training",
        "calibration_policy": "Always sigmoid on separate calibration window; no refit",
        "threshold_rule": "Max recall under validation capacity; ties: precision, then threshold",
        "source_sha256": code_hashes, "models": {},
        "sql_sha256": {p.name: checksum(p) for p in sorted(SQL_DIR.glob("*.sql"))}}
    Xt, yt = xy(windows["train"])
    Xc, yc = xy(windows["calibration"])
    Xv, yv = xy(windows["threshold"])
    for group, result in champions.items():
        fitted = build_model(result["spec"], yt, config).fit(Xt, yt)
        calibrator = CalibratedClassifierCV(FrozenEstimator(fitted), method="sigmoid")
        calibrator.fit(Xc, yc)
        probabilities = calibrator.predict_proba(Xv)[:, 1]
        threshold = select_threshold(yv, probabilities, config["review_capacity"])
        raw_probabilities = fitted.predict_proba(Xv)[:, 1]
        raw_threshold = select_threshold(yv, raw_probabilities, config["review_capacity"])
        bundle = ModelBundle(fitted, calibrator, threshold, f"{run_id}-{group}",
                             {"features": FEATURES, "versions": versions(),
                              "spec": result["spec"], "data_kind": manifest["data_kind"],
                              "csv_sha256": provenance["csv_sha256"]})
        path = run_dir / f"{group}.joblib"
        save_bundle(bundle, path)
        scenarios = [{"capacity": capacity, **evaluate_scores(
            yv, probabilities, select_threshold(yv, probabilities, capacity), config["cost_scenario"])}
            for capacity in config["capacity_scenarios"]]
        manifest["models"][group] = {
            "artifact": path.name, "artifact_sha256": checksum(path), "cv": result,
            "threshold": threshold, "uncalibrated_threshold": raw_threshold,
            "validation_calibrated": evaluate_scores(yv, probabilities, threshold),
            "validation_uncalibrated": evaluate_scores(yv, raw_probabilities, raw_threshold),
            "validation_capacity_scenarios": scenarios}
        if group == winner:
            save_bundle(bundle, run_dir / "model.joblib")
            manifest["serving_artifact_sha256"] = checksum(run_dir / "model.joblib")
            threshold_table(yv, probabilities).to_csv(run_dir / "validation_thresholds.csv", index=False)
            classifier = fitted.named_steps["classifier"]
            importance = getattr(classifier, "feature_importances_", None)
            if importance is None and hasattr(classifier, "coef_"):
                importance = np.abs(classifier.coef_[0])
            if importance is not None:
                pd.DataFrame({"feature": fitted.named_steps["features"].get_feature_names_out(),
                              "importance": importance}).sort_values("importance", ascending=False).to_csv(
                                  run_dir / "feature_importance.csv", index=False)
    manifest["state"] = "frozen_before_final_test"
    write_json(run_dir / "manifest.json", manifest)
    print(f"Frozen winner: {winner}; run={run_dir}", flush=True)
    return manifest
