"""Small reproducibility helpers."""

import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path

PACKAGES = ["duckdb", "pandas", "numpy", "scikit-learn", "xgboost", "joblib",
            "fastapi", "pydantic", "matplotlib"]


def checksum(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def versions() -> dict:
    return {"python": platform.python_version(),
            **{name: importlib.metadata.version(name) for name in PACKAGES}}


def write_json(path: str | Path, value: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))
