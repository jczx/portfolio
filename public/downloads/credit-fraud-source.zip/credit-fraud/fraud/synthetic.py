"""Artificial fixtures for software execution only, never model-performance evidence."""

from pathlib import Path

import numpy as np
import pandas as pd

from fraud.io import write_json
from fraud.schema import RAW_COLUMNS


def make_synthetic(path, rows=1200, seed=42):
    if rows < 400:
        raise ValueError("Use at least 400 rows for chronological smoke windows")
    rng = np.random.default_rng(seed)
    values = rng.normal(size=(rows, 28))
    labels = (np.arange(rows) % 17 == 0).astype(int)
    values[:, 0] += 2.5 * labels
    values[:, 3] -= 2 * labels
    frame = pd.DataFrame(values, columns=[f"V{i}" for i in range(1, 29)])
    frame["Time"] = np.floor(np.arange(rows) / 2) * 5.0
    frame["Amount"] = rng.lognormal(3, 1.2, rows)
    frame["Class"] = labels
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame[RAW_COLUMNS].to_csv(path, index=False)
    write_json(path.with_suffix(".provenance.json"), {"synthetic": True, "seed": seed,
                                                      "purpose": "Software tests only"})
    return frame[RAW_COLUMNS]
