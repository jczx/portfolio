"""Read-only final-test scoring of already frozen model choices."""

from pathlib import Path

import pandas as pd

from fraud.artifacts import load_bundle
from fraud.data import load_frame
from fraud.io import checksum, read_json, write_json
from fraud.metrics import evaluate_scores
from fraud.plots import evaluation_plots
from fraud.schema import xy
from fraud.splits import chronological_windows, describe_windows


def evaluate(run_dir, output_dir):
    run_dir, output_dir = Path(run_dir), Path(output_dir)
    manifest_path = run_dir / "manifest.json"
    manifest = read_json(manifest_path)
    if manifest["state"] != "frozen_before_final_test":
        raise ValueError("Training choices must be frozen before evaluation")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError("Evaluation output already exists; use a new output directory")
    config = manifest["config"]
    if ("database_sha256" in manifest and
            checksum(run_dir / "data.duckdb") != manifest["database_sha256"]):
        raise ValueError("Database changed after choices were frozen")
    frame = load_frame(run_dir / "data.duckdb", manifest["provenance"]["csv_sha256"])
    windows = chronological_windows(frame, config["split_fractions"], config["min_positives"])
    if describe_windows(windows) != manifest["split_audit"]["windows"]:
        raise ValueError("Split boundaries differ from the frozen run")
    X, y = xy(windows["test"])
    results, predictions = {}, {}
    for name, model_info in manifest["models"].items():
        path = run_dir / model_info["artifact"]
        if checksum(path) != model_info["artifact_sha256"]:
            raise ValueError("Artifact changed after choices were frozen")
        bundle = load_bundle(path)
        raw, calibrated = bundle.predict(X, calibrated=False), bundle.predict(X)
        predictions[name] = {"uncalibrated": raw, "calibrated": calibrated}
        results[name] = {
            "uncalibrated": evaluate_scores(y, raw, model_info["uncalibrated_threshold"],
                                             config["cost_scenario"]),
            "calibrated": evaluate_scores(y, calibrated, bundle.threshold, config["cost_scenario"])}
    output_dir.mkdir(parents=True, exist_ok=True)
    report = {"data_kind": manifest["data_kind"], "run_id": manifest["run_id"],
              "frozen_manifest_sha256": checksum(manifest_path),
              "selected_group": manifest["selected_group"], "models": results,
              "note": "Test results are descriptive; never reselect models or thresholds on this window."}
    write_json(output_dir / "metrics.json", report)
    write_json(output_dir / "manifest.json", manifest)
    tradeoffs = pd.read_csv(run_dir / "validation_thresholds.csv")
    label = "SYNTHETIC SOFTWARE TEST ONLY" if manifest["data_kind"].startswith("synthetic") else "ULB"
    evaluation_plots(y, predictions, manifest["selected_group"], tradeoffs, output_dir, label)
    lines = [f"# {label}: final-test report", "", f"Frozen choice: **{manifest['selected_group']}**.",
             "", "| Model | Average precision | Trapezoidal PR-AUC | Precision | Recall | Alerts | FP | Missed fraud |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for name, pair in results.items():
        m = pair["calibrated"]
        lines.append(f"| {name} | {m['average_precision']:.4f} | {m['trapezoidal_pr_auc']:.4f} | "
                     f"{m['precision']:.4f} | {m['recall']:.4f} | {m['alerts']} | "
                     f"{m['false_positives']} | {m['missed_fraud']} |")
    lines.extend(["", "Thresholds were selected on the preceding validation window. "
                  "Capacity is a validation constraint, not a guarantee on future alert volume.", "",
                  "See metrics.json for calibration scores, uncertainty intervals and illustrative costs. "
                  "The dummy score ties all transactions; trapezoidal PR interpolation can appear optimistic. "
                  "Average precision is the selection metric."])
    (output_dir / "results.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    return report
