"""Time-group-aware chronological windows and forward validation."""

from itertools import combinations

import numpy as np
import pandas as pd

from fraud.schema import FEATURES, RAW_COLUMNS

WINDOWS = ["train", "calibration", "threshold", "test"]


def chronological_windows(frame, fractions=(0.6, 0.15, 0.1, 0.15), min_positives=5):
    if len(fractions) != 4 or min(fractions) <= 0 or not np.isclose(sum(fractions), 1):
        raise ValueError("Four positive split fractions must sum to one")
    ordered = frame.sort_values(["Time", "row_id"], kind="stable").reset_index(drop=True)
    times = ordered.Time.to_numpy()
    cuts = [0]
    for fraction in np.cumsum(fractions)[:-1]:
        target = min(int(len(ordered) * fraction), len(ordered) - 1)
        cuts.append(int(np.searchsorted(times, times[target], side="left")))
    cuts.append(len(ordered))
    windows = {name: ordered.iloc[start:end].copy()
               for name, start, end in zip(WINDOWS, cuts[:-1], cuts[1:])}
    for name, part in windows.items():
        require_classes(part, min_positives, name)
    return windows


def require_classes(frame, min_positives, name):
    positives = int(frame.Class.sum())
    if positives < min_positives or len(frame) - positives < min_positives:
        raise ValueError(f"{name} needs at least {min_positives} examples of each class; "
                         f"found {positives} positive / {len(frame) - positives} negative. "
                         "Adjust and document split fractions before modelling; no automatic retry.")


def forward_folds(train, n_splits=3, min_positives=2):
    if n_splits < 2:
        raise ValueError("At least two forward folds are required")
    times = train.Time.to_numpy()
    if not np.all(times[:-1] <= times[1:]):
        raise ValueError("Forward validation requires sorted elapsed time")
    cuts = [int(np.searchsorted(times, times[int(len(train) * i / (n_splits + 1))],
                               side="left")) for i in range(1, n_splits + 1)] + [len(train)]
    for i, (start, stop) in enumerate(zip(cuts[:-1], cuts[1:])):
        fit, validation = train.iloc[:start], train.iloc[start:stop]
        require_classes(fit, min_positives, f"fold {i} fit")
        require_classes(validation, min_positives, f"fold {i} validation")
        yield fit, validation


def describe_windows(windows):
    return {name: {"rows": len(part), "positives": int(part.Class.sum()),
                   "negatives": int(len(part) - part.Class.sum()),
                   "min_time": float(part.Time.min()), "max_time": float(part.Time.max())}
            for name, part in windows.items()}


def duplicate_audit(windows):
    """Hash audit includes exact rows and feature signatures with/without elapsed time."""
    result = {}
    for label, columns in {"exact_rows": RAW_COLUMNS, "predictors": FEATURES,
                           "predictors_without_time": FEATURES[1:]}.items():
        hashes = {name: pd.util.hash_pandas_object(part[columns], index=False)
                  for name, part in windows.items()}
        result[label] = {
            "within_window_duplicate_rows": {name: int(values.duplicated().sum())
                                             for name, values in hashes.items()},
            "cross_window_shared_signatures": {
                f"{left}__{right}": len(set(hashes[left]) & set(hashes[right]))
                for left, right in combinations(windows, 2)}}
    return result
