"""One compatible inference bundle. Load only trusted local joblib files."""

from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np

from fraud.io import versions
from fraud.schema import FEATURES, validate_features

ARTIFACT_FORMAT = 1


@dataclass
class ModelBundle:
    classifier: object
    calibrator: object
    threshold: float
    model_version: str
    metadata: dict
    format_version: int = ARTIFACT_FORMAT

    def predict(self, frame, calibrated=True):
        X = validate_features(frame)
        model = self.calibrator if calibrated else self.classifier
        probabilities = model.predict_proba(X)[:, 1]
        if not np.isfinite(probabilities).all() or ((probabilities < 0) | (probabilities > 1)).any():
            raise ValueError("Artifact produced invalid probabilities")
        return probabilities


def save_bundle(bundle, path):
    joblib.dump(bundle, path, compress=3)


def load_bundle(path: str | Path):
    if not Path(path).is_file():
        raise FileNotFoundError(f"Trained model artifact missing: {path}. Run the train command first.")
    bundle = joblib.load(path)
    if not isinstance(bundle, ModelBundle) or bundle.format_version != ARTIFACT_FORMAT:
        raise ValueError("Incompatible artifact format")
    if bundle.metadata.get("features") != FEATURES:
        raise ValueError("Incompatible artifact feature schema")
    runtime = versions()
    for package in ["scikit-learn", "xgboost", "numpy", "pandas", "duckdb", "joblib"]:
        if bundle.metadata["versions"].get(package) != runtime[package]:
            raise ValueError(f"Incompatible {package} version; restore the training lockfile")
    if not np.isfinite(bundle.threshold) or not 0 <= bundle.threshold <= np.nextafter(1., np.inf):
        raise ValueError("Invalid artifact threshold")
    return bundle
