"""A small, explicit search space, with fold-local imbalance weights."""

from itertools import product

from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

from fraud.features import SQLFeatures


def candidates(config):
    yield {"family": "dummy", "weighted": False, "variant": "original", "parameter": None}
    for variant, weighted in product(["original", "log_amount"], [False, True]):
        for c in config["logistic_c"]:
            yield {"family": "logistic", "weighted": weighted, "variant": variant, "parameter": c}
        for depth in config["xgb_depth"]:
            yield {"family": "xgboost", "weighted": weighted, "variant": variant,
                   "parameter": depth}


def group_name(spec):
    return spec["family"] + ("_weighted" if spec["weighted"] else "_unweighted")


def build_model(spec, y_train, config):
    positives = int(y_train.sum())
    negatives = len(y_train) - positives
    if min(positives, negatives) == 0:
        raise ValueError("Training requires both classes")
    steps = [("features", SQLFeatures(spec["variant"]))]
    if spec["family"] == "dummy":
        classifier = DummyClassifier(strategy="prior")
    elif spec["family"] == "logistic":
        steps.append(("scale", StandardScaler()))
        classifier = LogisticRegression(C=spec["parameter"], max_iter=2000,
                                        class_weight="balanced" if spec["weighted"] else None,
                                        random_state=config["seed"])
    elif spec["family"] == "xgboost":
        classifier = XGBClassifier(
            max_depth=spec["parameter"], n_estimators=config["xgb_estimators"],
            learning_rate=0.08, subsample=0.9, colsample_bytree=0.9,
            tree_method="hist", device="cpu", objective="binary:logistic",
            eval_metric="logloss", scale_pos_weight=negatives/positives if spec["weighted"] else 1,
            n_jobs=config["n_jobs"], random_state=config["seed"])
    else:
        raise ValueError("Unknown model family")
    return Pipeline([*steps, ("classifier", classifier)])
